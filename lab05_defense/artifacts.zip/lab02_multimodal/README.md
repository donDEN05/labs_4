# Лабораторная 2. Мультимодальные модели

Разработка многоагентной системы персонализированного управления скидками в электронной коммерции

Отчёт: report.docx. Литература: literature.csv. Паспорт: data_card.json. Конфигурация и фактические журналы: config.json и results/.

Запуск из корня проекта:

```powershell
.venv/Scripts/python.exe lab02_multimodal/run.py
.venv/Scripts/python.exe lab02_multimodal/test_lab.py
```

Данные и зависимости общие: ../shared и ../requirements.txt. Точная последовательность подготовки находится в корневом README.md. Полноценное повторение LLM требует загрузки весов; smoke-проверки не заменяют эксперимент.
